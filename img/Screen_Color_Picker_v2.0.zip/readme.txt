If the hotkey isn't working in overlay

or fullscreen applications or games,

restart this tool as administrator.


Icon by Mazenl77

Tool by www.2xDSoft.ru.gg